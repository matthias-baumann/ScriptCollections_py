Workflow

1. Collect information on LEDAPS+FMask processed files:
   - use getInputFileInfos(...)
   - see example_getInputFileInfos.pro
   
2. (Parallel-threaded) Preprocessing of he LEDAPS+FMask Output. 
   - Requires step 1.
   - use image_preprocessing(...)
   - see example_imagePreProcessing.pro
   
3. The preprocessing is done. Now you want to collect informations on all the files 
   that are available for the pixel-based compositing (PBC)
   - requires step 2.
   - use getImageMetaData(...) to collect all meta-infos in a fast-accessable IDL structure
   - create subsets of this metadata structure to describe a region of interest (e.g. a certain Path/Row tile)
   - use plotImageMetaData to plot some of the infos stored in the metaData structure
   - see example_imageMetaData.pro
   
   
   - use convertMetaDataStruct(metaData, /ToPGStyle) and
         convertMetaDataStruct(metaData, /ToBJStyle) to convert between different metadata representations
     This allows you to use the methods from step 1-3 with all other methods (at least in theory...)
     
4. create the active area mask
TODO

5. specify compositing rules
TODO

6. do the compositing
TODO